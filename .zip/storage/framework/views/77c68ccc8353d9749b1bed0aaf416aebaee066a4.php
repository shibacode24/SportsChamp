
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="row">
    <div class="col-md-2" style="margin-top: 2vh;"></div>
    <div class="col-md-8" style="margin-top: 2vh;">
        <form action="<?php echo e(route('blog_store')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
        <table width="80%">
            <tr style="height:30px;" >
                <th width="1%">Date</th>
                <th width="2%">Title of Blog</th>
                <th width="1%">Author Name</th>
                <th width="1%">Upload Blog Image</th>
              </tr>


            <tr>
                <td style="padding: 2px;" width="1%">
                    <input type="date" class="form-control" name="date" placeholder="" />
                    </div>
                </td>
                <td style="padding: 2px;" width="2%">
                    <input type="text" class="form-control" name="title" placeholder="" />
                </td>
                <td style="padding: 2px;" width="1%">
                    <input type="text" class="form-control" name="author_name" placeholder="" />
                </td>
                <td style="padding: 2px;" width="1%">
                    <input type="file" class="form-control" name="image" placeholder="" />
                </td>
                
            </tr>
 
        </table>
        <table width="100%" style="margin-top: 2vh;">
            <tr>
                <th width="40%">Content</th>
                <!-- <th width="5%"></th> -->
            </tr>
            <tr>
                <td style="padding: 2px;" width="40%">
                 <textarea class="form-control" id="editor" placeholder="content"
                    name="content"></textarea>
                </td>
                
            </tr>
        
            <tr>
                <td style="padding: 2px;text-align: center;" width="5%">
                    <button id="on" type="submit" class="btn mjks"
         style="color:#FFFFFF; height:30px; width:auto;background-color: #006699;"><i class="fa fa-floppy-o" aria-hidden="true"></i>
         Submit</button>   
                </td>   
            </tr>
         </table>
        </form>

    </div>

</div>
<div class="row">
    <div class="col-md-2" style="margin-top: 2vh;"></div>
    <div class="col-md-8" style="margin-top:15px;">

        <!-- START DEFAULT DATATABLE -->
      
             <div class="panel-body" style="margin-top:5px; margin-bottom:15px;">
                <table class="table datatable">
                    <thead>
                        <tr>
                            <th>Sr. No.</th>
                            <th>Date</th>
                            <th>Title of Blog</th>
                            <th>Author Name</th>
                            <th>Uploaded Blog Image</th>
                          
                          
                            <th>Content</th>
                           
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $blog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blogs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($blogs->date); ?></td>
                            <td><?php echo e($blogs->title); ?></td>
                            <td><?php echo e($blogs->author_name); ?></td>
                            <td>
                                <a href="<?php echo e(asset('images/blog_image/' . $blogs->image)); ?>" target="_blank">
                                <img src="<?php echo e(asset('images/blog_image/' . $blogs->image)); ?>" width="50" height="50"/>
                                </a>
                            </td>
                          <td><?php echo $blogs->content; ?></td>
                          
                         
                            <td>
                                <a href="<?php echo e(route('blog_edit', $blogs->id)); ?>">
                                <button style="background-color:#3399ff; border:none; max-height:25px; margin-top:-5px; margin-bottom:-5px;" type="button" class="btn btn-info" data-toggle="tooltip" data-placement="top" title="Edit"><i class="fa fa-edit" style="margin-left:5px;"></i></button>
                                </a>
                                <button onclick="openCustomModal('<?php echo e(route('blog_destroy', $blogs->id)); ?>')"
                                    id="customModal" style="background-color:#ff0000; border:none; max-height:25px; margin-top:-5px; margin-bottom:-5px;" type="button" class="btn btn-info" data-toggle="tooltip" data-placement="top" title="Delete"><i class="fa fa-trash-o" style="margin-left:5px;"></i></button>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                       
                    </tbody>
                </table>
            </div>
    
        <!-- END DEFAULT DATATABLE -->


    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\webmedia-project\sportschamp2\resources\views/masters/blog.blade.php ENDPATH**/ ?>