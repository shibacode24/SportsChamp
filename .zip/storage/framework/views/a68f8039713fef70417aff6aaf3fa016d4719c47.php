
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<form action="<?php echo e(route('school_store')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <div class="col-md-12" style="margin-top: 2vh;">
        <table width="100%">
            <tr style="height:30px;">
                <th width="2%">Date</th>
                <th width="2%">School Code</th>
                <th width="3%">School Name</th>
                <th width="2%">Address</th>
                <th width="2%">City</th>
                <th width="3%">Contact Person Name</th>
                <th width="2%">Contact No.</th>
                <th width="2%">Email</th>
                <th width="1%">Latitude</th>
                <th width="1%">Longitude </th>
                <th width="2%"></th>
            </tr>


            <tr>
                

                     

                <td style="padding: 1px;" width="1%">
                    <input type="date" class="form-control" name="date" placeholder="" />
                </td>

                <td style="padding: 2px;" width="2%">
                    <input type="text" class="form-control" name="school_code" placeholder="" />
                </td>

                <td style="padding: 2px;" width="3%">
                    <input type="text" class="form-control" name="school_name" placeholder="" />
                </td>
                <td style="padding: 2px;" width="2%">
                    <input type="text" class="form-control" name="address" placeholder="" />
                </td>
                <td style="padding: 2px;" width="2%">
                    <select class="form-control select" data-live-search="true" name="city_id">
                        <option value="">Select</option>
                        <?php $__currentLoopData = $city; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cities): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($cities->id); ?>"><?php echo e($cities->city_name); ?></option> 
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </td>
                <td style="padding: 2px;" width="3%">
                    <input type="text" class="form-control" name="contact_person_name" placeholder="" />
                </td>
                <td style="padding: 2px;" width="2%">
                    <input type="text" class="form-control" name="contact_no" maxlength="10" placeholder="" />
                </td>
                <td style="padding: 2px;" width="2%">
                    <input type="text" class="form-control" name="email" placeholder="" />
                </td>
                <td style="padding: 2px;" width="1%">
                    <input type="text" class="form-control" name="latitude" placeholder="" />
                </td>
                <td style="padding: 2px;" width="1%">
                    <input type="text" class="form-control" name="longitude" placeholder="" />
                </td>
                <td>
                    <button id="on" type="submit" class="btn mjks"
                        style="color:#FFFFFF; height:30px; width:auto;background-color: #006699;"><i class="fa fa-floppy-o"
                            aria-hidden="true"></i>
                        Submit</button>
                </td>
            </tr>

        </table>



    </div>
</form>

    </div>
    <div class="row">
        <div class="col-md-12" style="margin-top:15px;">

            <!-- START DEFAULT DATATABLE -->

            <div class="panel-body" style="margin-top:5px; margin-bottom:15px;">
                <table class="table datatable">
                    <thead>
                        <tr>
                            <th>Sr. No.</th>
                            <th>Date</th>
                            <th>School Code</th>
                            <th>School Name</th>
                            <th>Address</th>

                            <th>City</th>
                            <th>Contact Person Name</th>
                            <th>Contact No.</th>
                            <th>Email</th>
                            <th>Lat/Lang</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $school; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schools): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>     
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($schools->date); ?></td>
                            <td><?php echo e($schools->school_code); ?></td>
                            <td><?php echo e($schools->school_name); ?></td>
                            <td><?php echo e($schools->address); ?></td>
                            <td><?php echo e($schools->city_name->city_name); ?></td>
                            <td><?php echo e($schools->contact_person_name); ?></td>
                            <td><?php echo e($schools->contact_no); ?></td>
                            <td><?php echo e($schools->email); ?></td>
                            <td><?php echo e($schools->latitude); ?></td>
                            <td><?php echo e($schools->longitude); ?></td>
                            <td>
                                        
                              <a href="<?php echo e(route('school_edit',$schools->id)); ?>">  <button style="background-color:#3399ff; border:none; max-height:25px; margin-top:-5px; margin-bottom:-5px;" type="button" class="btn btn-info" data-toggle="tooltip" data-placement="top" title="Edit"><i class="fa fa-edit" style="margin-left:5px;"></i></button>
                              </a>
                             
                                 <button  onclick="openCustomModal('<?php echo e(route('school_destroy',$schools->id)); ?>')" id="customModal"
                            style="background-color:#ff0000; border:none; max-height:25px; margin-top:-5px; margin-bottom:-5px;" type="button" class="btn btn-info" data-toggle="tooltip" data-placement="top" title="Delete"><i class="fa fa-trash-o" style="margin-left:5px;"></i></button>

                            
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            </div>

            <!-- END DEFAULT DATATABLE -->


        </div>
    </div>

    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\webmedia-project\sportschamp2\resources\views/masters/school.blade.php ENDPATH**/ ?>