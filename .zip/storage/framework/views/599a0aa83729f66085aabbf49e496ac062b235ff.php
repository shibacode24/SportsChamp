
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <form action="<?php echo e(route('update_school')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="id" value="<?php echo e($school_edit->id); ?>">
        <div class="col-md-12" style="margin-top: 2vh;">
            <table width="100%">
                <tr style="height:30px;">
                    <th width="2%">Date</th>
                    <th width="2%">School Code</th>
                    <th width="3%">School Name</th>
                    <th width="2%">Address</th>
                    <th width="2%">City</th>
                    <th width="3%">Contact Person Name</th>
                    <th width="2%">Contact No.</th>
                    <th width="2%">Email</th>
                    <th width="1%">Latitude</th>
                    <th width="1%">Longitude </th>
                    <th width="2%"></th>
                </tr>


                <tr>
                    

                    

                    <td style="padding: 1px;" width="1%">
                        <input type="date" class="form-control" name="date" value="<?php echo e($school_edit->date); ?>" placeholder="" />
                    </td>

                    <td style="padding: 2px;" width="2%">
                        <input type="text" class="form-control" name="school_code" value="<?php echo e($school_edit->school_code); ?>" placeholder="" />
                    </td>

                    <td style="padding: 2px;" width="3%">
                        <input type="text" class="form-control" name="school_name" value="<?php echo e($school_edit->school_name); ?>" placeholder="" />
                    </td>
                    <td style="padding: 2px;" width="2%">
                        <input type="text" class="form-control" name="address" value="<?php echo e($school_edit->address); ?>" placeholder="" />
                    </td>
                    <td style="padding: 2px;" width="2%">
                        <select class="form-control select" data-live-search="true" name="city_id">
                            <option value="">Select</option>
                            <?php $__currentLoopData = $city; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cities): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($cities->id); ?>" <?php if($school_edit->city_id == $cities->id): ?> selected <?php endif; ?>><?php echo e($cities->city_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </td>
                    <td style="padding: 2px;" width="3%">
                        <input type="text" class="form-control" name="contact_person_name" value="<?php echo e($school_edit->contact_person_name); ?>" placeholder="" />
                    </td>
                    <td style="padding: 2px;" width="2%">
                        <input type="text" class="form-control" name="contact_no" maxlength="10" value="<?php echo e($school_edit->contact_no); ?>" placeholder="" />
                    </td>
                    <td style="padding: 2px;" width="2%">
                        <input type="text" class="form-control" name="email" value="<?php echo e($school_edit->email); ?>" placeholder="" />
                    </td>
                    <td style="padding: 2px;" width="1%">
                        <input type="text" class="form-control" name="latitude" value="<?php echo e($school_edit->latitude); ?>" placeholder="" />
                    </td>
                    <td style="padding: 2px;" width="1%">
                        <input type="text" class="form-control" name="longitude" value="<?php echo e($school_edit->longitude); ?>" placeholder="" />
                    </td>
                    <td>
                        <button id="on" type="submit" class="btn mjks"
                            style="color:#FFFFFF; height:30px; width:auto;background-color: #006699;"><i
                                class="fa fa-floppy-o" aria-hidden="true"></i>
                            update</button>
                    </td>
                </tr>

            </table>



        </div>
    </form>

    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\sportschamp1\resources\views/masters/school_edit.blade.php ENDPATH**/ ?>