
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<form action="<?php echo e(route('update_employee')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="id" value="<?php echo e($employee_edit->id); ?>">
    <div class="row">
        <div class="col-md-12" style="margin-top: 2vh;">
            <table width="80%">
                <tr style="height:30px;">
                    <th width="1%">Date</th>
                    <th width="1%">Select Designation</th>
                    <th width="1%">City</th>
                    <th width="1%">Emp Code</th>
                    <th width="1%">Assign School</th>
                    <th width="3%">Name</th>

                </tr>


                <tr>
                    <td style="padding: 2px;" width="1%">
                        

                        
                        
                        <input type="date" class="form-control" name="date" value="<?php echo e($employee_edit->date); ?>" placeholder="" />
                    </td>
                    <td style="padding: 2px;" width="2%">
                        <select class="form-control select" data-live-search="true"  name="designation_id">
                            <option value="">Select</option>
                            <?php $__currentLoopData = $designation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $designations): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($designations->id); ?>" <?php if($employee_edit->designation_id == $designations->id): ?> selected <?php endif; ?>><?php echo e($designations->designation); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </td>
                    <td style="padding: 2px;" width="2%">
                        <select class="form-control select" data-live-search="true" name="city_id">
                            <option value="">Select</option>
                            <?php $__currentLoopData = $city; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cities): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($cities->id); ?>"  <?php if($employee_edit->city_id == $cities->id): ?> selected <?php endif; ?>><?php echo e($cities->city_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </td>

                    <td style="padding: 2px;" width="3%">
                        <input type="text" class="form-control" name="emp_code" value="<?php echo e($employee_edit->emp_code); ?>" placeholder="" />
                    </td>

                    <td style="padding: 2px;" width="2%">
                        <select class="form-control select" data-live-search="true" name="school_id">
                            <option value="">Select</option>
                            <?php $__currentLoopData = $school; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $school): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($school->id); ?>" <?php if($employee_edit->school_id == $school->id): ?> selected <?php endif; ?>><?php echo e($school->school_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </td>

                    <td style="padding: 2px;" width="3%">
                        <input type="text" class="form-control" name="name" value="<?php echo e($employee_edit->name); ?>" placeholder="" />
                    </td>
                </tr>
                <tr style="height:30px;">

                    <th width="2%">Email</th>
                    <th width="1%">Mobile No.</th>

                    <th width="2%">Address</th>
                    <th width="1%">Pincode</th>
                    <th width="1%">Username</th>
                    <th width="1%">Password</th>
                    <th width="1%"></th>
                </tr>
                <tr>
                    <td style="padding: 2px;" width="2%">
                        <input type="text" class="form-control" name="email" value="<?php echo e($employee_edit->email); ?>" placeholder="" />
                    </td>
                    <td style="padding: 2px;" width="1%">
                        <input type="text" class="form-control" name="contact_no" maxlength="10" value="<?php echo e($employee_edit->contact_no); ?>" placeholder="" />
                    </td>
                    <td style="padding: 2px;" width="1%">
                        <input type="text" class="form-control" name="address" value="<?php echo e($employee_edit->address); ?>" placeholder="" />
                    </td>
                    <td style="padding: 2px;" width="1%">
                        <input type="text" class="form-control" name="pincode" value="<?php echo e($employee_edit->pincode); ?>" placeholder="" />
                    </td>
                    <td style="padding: 2px;" width="1%">
                        <input type="text" class="form-control" name="username" value="<?php echo e($employee_edit->username); ?>" placeholder="" />
                    </td>
                    <td style="padding: 2px;" width="2%">
                        <input type="text" class="form-control" name="password" placeholder="" />
                    </td>
                    <td style="padding: 2px;" width="2%">
                        <button id="on" type="submit" class="btn mjks"
                            style="color:#FFFFFF; height:30px; width:auto;background-color: #006699;"><i
                                class="fa fa-floppy-o" aria-hidden="true"></i>
                            Update</button>
                    </td>
                </tr>
            </table>



        </div>

    </div>
</form>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\sportschamp1\resources\views/masters/employee_edit.blade.php ENDPATH**/ ?>