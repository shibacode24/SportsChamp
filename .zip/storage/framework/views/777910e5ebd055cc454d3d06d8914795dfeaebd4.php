<table width="100%" border="1" style="margin-top: 5px;">
                        <tr style="background-color:#f0f0f0; height:30px;">
                            <th width="3%" style="text-align:center">Class</th>
                            <th width="5%" style="text-align:center">Section</th>
                            <th width="5%" style="text-align:center">Roll No.</th>
                            <th width="5%" style="text-align:center">Name</th>
                            <th width="5%" style="text-align:center">Parent Name</th>
                            <th width="5%" style="text-align:center">Mobile</th>
                         
                           
                        </tr>


<?php $__currentLoopData = $student_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td style="padding:5px;" align="center">
            <label><?php echo e($student->class); ?></label>
        </td>
        <td style="padding:5px;" align="center"><?php echo e($student->section); ?></td>
        <td style="padding:5px;" align="center"><?php echo e($student->roll_no); ?></td>
        <td style="padding:5px;" align="center"><?php echo e($student->name); ?></td>
        <td style="padding:5px;" align="center"><?php echo e($student->parent_name); ?></td>
        <td style="padding:5px;" align="center"><?php echo e($student->mobile_no); ?></td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        
                    </table><?php /**PATH C:\wamp64\www\sportschamp1\resources\views/masters/student_list.blade.php ENDPATH**/ ?>