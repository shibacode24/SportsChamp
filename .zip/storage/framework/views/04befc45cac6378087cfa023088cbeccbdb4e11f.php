
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="row">
    <div class="col-md-3" style="margin-top: 2vh;"></div>
    <div class="col-md-6" style="margin-top: 2vh;">
        <form action="<?php echo e(route('grade_card_store')); ?>" method="post">
            <?php echo csrf_field(); ?>
        <table width="100%" >
            <tr style="height:30px;" >
              <th width="1%">Select Grade</th>
                
            </tr>
            <tr>
                <td style="padding: 2px;" width="1%">
                    <select class="form-control select" data-live-search="true" name="grade_id"
                    id="grade_id_option">
                    <option value="">Select</option>
                    <?php $__currentLoopData = $grade; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grade1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($grade1->id); ?>"><?php echo e($grade1->grade); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </select>
                </td>
            </tr>

            <tr style="height:30px;" >
              <th width="3%">Add Grade Card Action</th>
             
            </tr>


            <tr style="height:30px;">
                <td style="padding: 2px;" width="2%">
                    <textarea class="form-control" id="editor" placeholder="content"
                    name="grade_content"></textarea>
                </td>
              
            </tr>
            <tr style="height:30px;" >
                <th width="2%"></th>
            </tr>
            <tr style="height:30px;text-align: center;">
                <td>
                    <button id="on" type="submit" class="btn mjks"
                   style="color:#FFFFFF; height:30px; width:auto;background-color: #006699;"><i class="fa fa-plus" aria-hidden="true"></i>
                   Submit</button>   
                          </td>   
                </tr>
        </table>
        </form>
    </div>

</div>
<div class="row">
    <div class="col-md-3" style="margin-top: 2vh;"></div>
    <div class="col-md-6" style="margin-top:15px;">

        <!-- START DEFAULT DATATABLE -->
      
             <div class="panel-body" style="margin-top:5px; margin-bottom:15px;">
                <table class="table datatable">
                    <thead>
                        <tr>
                            <th>Sr. No.</th>
                            <th>Selected Grade</th>
                            <th>Added Grade card action</th>
                          
                           <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $grade_card; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grade_cards): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($grade_cards->grade_name->grade); ?></td>
                            <td><?php echo e($grade_cards->grade_content); ?></td>
                          
                            <td>
                                <a href="<?php echo e(route('grade_card_edit', $grade_cards->id)); ?>">
                                <button style="background-color:#3399ff; border:none; max-height:25px; margin-top:-5px; margin-bottom:-5px;" type="button" class="btn btn-info" data-toggle="tooltip" data-placement="top" title="Edit"><i class="fa fa-edit" style="margin-left:5px;"></i></button>
                                </a>
                                <button onclick="openCustomModal('<?php echo e(route('grade_card_destroy', $grade_cards->id)); ?>')"
                                    id="customModal" style="background-color:#ff0000; border:none; max-height:25px; margin-top:-5px; margin-bottom:-5px;" type="button" class="btn btn-info" data-toggle="tooltip" data-placement="top" title="Delete"><i class="fa fa-trash-o" style="margin-left:5px;"></i></button>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                       
                    </tbody>
                </table>
            </div>
    
        <!-- END DEFAULT DATATABLE -->


    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\webmedia-project\sportschamp2\resources\views/masters/grade_card.blade.php ENDPATH**/ ?>