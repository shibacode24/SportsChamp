<table width="100%" border="1" style="margin-top: 5px;">
    <tr style="background-color:#f0f0f0; height:30px;">
        <th width="3%" style="text-align:center">Prop Name</th>
        <th width="5%" style="text-align:center">Quantity</th>
     
       
    </tr>


<?php $__currentLoopData = $issue_prop_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<td style="padding:5px;" align="center"><?php echo e($prop->prop_name->prop_name); ?></td>
<td style="padding:5px;" align="center"><?php echo e($prop->quntity); ?></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    
</table><?php /**PATH C:\wamp64\www\sportschamp1\resources\views/masters/issue_prop_list.blade.php ENDPATH**/ ?>