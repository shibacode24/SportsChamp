
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="row">
        <div class="col-md-12" style="margin-top: 2vh;">
            <form action="<?php echo e(route('masters')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="col-md-2">
                    <label class="control-label">Add City<font color="#FF0000">*</font></label>
                    <input type="text" class="form-control" name="city_name" placeholder="" />
                </div>

                <div class="col-md-2" style="margin-top:15px;">
                    <button id="on" type="submit" class="btn mjks" style="color:#FFFFFF; height:30px; width:auto;">
                        <i class="fa fa-plus"></i>ADD</button>
                    <button id="on" type="button" data-toggle="modal" data-target="#popup8" class="btn mjks"
                        style="color:#FFFFFF; height:30px; width:auto;"> <i class="fa fa-gear"></i>Manage</button>

                </div>

            </form>

            <!-- =========================================City model===================== -->
            <div class="modal" id="popup8" tabindex="-1" role="dialog" aria-labelledby="smallModalHead"
                aria-hidden="true">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal"><span
                                    aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                            <h4 class="modal-title" id="H4">Added City</h4>
                        </div>
                        <div class="modal-body" style="height:30%;padding: 10px;">
                            <div class="panel-body" style="margin-top:5px; margin-bottom:15px;">
                                <table class="table datatable">
                                    <thead>

                                        <tr>
                                            <th>Sr. No.</th>

                                            <th>Added City</th>

                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $city; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cities): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($loop->iteration); ?></td>

                                                <td><?php echo e($cities->city_name); ?></td>

                                                <td>
                                                    <button data-toggle="modal" value="<?php echo e($cities->id); ?>"
                                                        city_name="<?php echo e($cities->city_name); ?>" data-target="#popup13"
                                                        style="background-color:#3399ff; border:none; max-height:25px; margin-top:-5px; margin-bottom:-5px;"
                                                        type="button" class="btn btn-info editbtn_city"
                                                        data-toggle="tooltip" data-placement="top" title="Edit"><i
                                                            class="fa fa-edit" style="margin-left:5px;"></i></button>
                                                    <a href="<?php echo e(route('city_destroy', $cities->id)); ?>">
                                                        <button
                                                            style="background-color:#ff0000; border:none; max-height:25px; margin-top:-5px; margin-bottom:-5px;"
                                                            type="button" class="btn btn-info" data-toggle="tooltip"
                                                            data-placement="top" title="Delete"><i class="fa fa-trash-o"
                                                                style="margin-left:5px;"></i></button>
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="modal-footer" style="border: none !important; background-color: #FFF !important;">
                            <!-- <button type="button" class="btn btn-default" data-dismiss="modal">Close</button> -->
                        </div>
                    </div>
                </div>
            </div>


            <!-- ===============================edit city======================== -->
            <div class="modal" id="popup13" tabindex="-1" role="dialog" aria-labelledby="smallModalHead"
                aria-hidden="true">
                <div class="modal-dialog modal-sm">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal"><span
                                    aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                            <h4 class="modal-title" id="H4">Update City</h4>
                        </div>
                        <div class="modal-body" style="height:30%;padding: 10px;">
                            <div class="panel-body" style="margin-top:5px; margin-bottom:15px;">
                                <div class="col-md-12">
                                    <form action="<?php echo e(route('update_city')); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" value="" id="city_id" name="city_id" />
                                        <div class="col-md-6">
                                            <label class="control-label"> City<font color="#FF0000">*</font></label>
                                            <input type="text" class="form-control" id="city_name" name="city_name"
                                                placeholder="" />
                                        </div>

                                        <div class="col-md-6" style="margin-top:15px;padding-left: 10px;">
                                            <button id="on" type="submit" class="btn mjks"
                                                style="color:#FFFFFF; height:30px; width:auto;"> <i
                                                    class="fa fa-plus"></i>Update</button>


                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer" style="border: none !important; background-color: #FFF !important;">
                            <!-- <button type="button" class="btn btn-default" data-dismiss="modal">Close</button> -->
                        </div>
                    </div>
                </div>
            </div>
            

            <!-- ======================================designation start================================== -->
            <form action="<?php echo e(route('designation_store')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="col-md-2">
                    <label class="control-label">Add Designation<font color="#FF0000">*</font></label>
                    <input type="text" class="form-control" name="designation" placeholder="" />
                </div>

                <div class="col-md-2" style="margin-top:15px;">
                    <button id="on" type="submit" class="btn mjks"
                        style="color:#FFFFFF; height:30px; width:auto;"> <i class="fa fa-plus"></i>ADD</button>
                    <button id="on" type="button" data-toggle="modal" data-target="#popup3" class="btn mjks"
                        style="color:#FFFFFF; height:30px; width:auto;"> <i class="fa fa-gear"></i>Manage</button>

                </div>
            </form>

            <div class="modal" id="popup3" tabindex="-1" role="dialog" aria-labelledby="smallModalHead"
                aria-hidden="true">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal"><span
                                    aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                            <h4 class="modal-title" id="H4">Added Designation</h4>
                        </div>
                        <div class="modal-body" style="height:30%;padding: 10px;">
                            <div class="panel-body" style="margin-top:5px; margin-bottom:15px;">
                                <table class="table datatable">
                                    <thead>
                                        <tr>
                                            <th>Sr. No.</th>

                                            <th>Added Designation</th>

                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $designation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $designations): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>

                                                <td><?php echo e($loop->iteration); ?></td>

                                                <td><?php echo e($designations->designation); ?></td>


                                                <td>

                                                    <button data-toggle="modal" data-target="#popup14"
                                                        value="<?php echo e($designations->id); ?>"
                                                        designation_name="<?php echo e($designations->designation); ?>"
                                                        style="background-color:#3399ff; border:none; max-height:25px; margin-top:-5px; margin-bottom:-5px;"
                                                        type="button" class="btn btn-info editbtn_designation"
                                                        data-toggle="tooltip" data-placement="top" title="Edit"><i
                                                            class="fa fa-edit" style="margin-left:5px;"></i></button>
                                                    <a href="<?php echo e(route('designation_destroy', $designations->id)); ?>">
                                                        <button
                                                            style="background-color:#ff0000; border:none; max-height:25px; margin-top:-5px; margin-bottom:-5px;"
                                                            type="button" class="btn btn-info" data-toggle="tooltip"
                                                            data-placement="top" title="Delete"><i class="fa fa-trash-o"
                                                                style="margin-left:5px;"></i></button>
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="modal-footer" style="border: none !important; background-color: #FFF !important;">
                            <!-- <button type="button" class="btn btn-default" data-dismiss="modal">Close</button> -->
                        </div>
                    </div>
                </div>
            </div>

            <div class="modal" id="popup14" tabindex="-1" role="dialog" aria-labelledby="smallModalHead"
                aria-hidden="true">
                <div class="modal-dialog modal-sm">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal"><span
                                    aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                            <h4 class="modal-title" id="H4">Update Designation</h4>
                        </div>
                        <div class="modal-body" style="height:30%;padding: 10px;">
                            <div class="panel-body" style="margin-top:5px; margin-bottom:15px;">
                                <form action="<?php echo e(route('update_designation')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" id="designation_id" name="designation_id">
                                    <div class="col-md-12">

                                        <div class="col-md-6">
                                            <label class="control-label"> Designation<font color="#FF0000">*</font>
                                            </label>
                                            <input type="text" class="form-control" id="designation"
                                                name="designation" placeholder="" />
                                        </div>

                                        <div class="col-md-6" style="margin-top:15px;padding-left: 10px;">
                                            <button id="on" type="submit" class="btn mjks"
                                                style="color:#FFFFFF; height:30px; width:auto;"> <i
                                                    class="fa fa-plus"></i>Update</button>


                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <div class="modal-footer" style="border: none !important; background-color: #FFF !important;">
                            <!-- <button type="button" class="btn btn-default" data-dismiss="modal">Close</button> -->
                        </div>
                    </div>
                </div>
            </div>
            <!-- ================= designation end======================-->
            <form action="<?php echo e(route('grade_store')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="col-md-2">
                    <label class="control-label">Add Grade<font color="#FF0000">*</font></label>
                    <input type="text" class="form-control" name="grade" placeholder="" />
                </div>

                <div class="col-md-2" style="margin-top:15px;">
                    <button id="on" type="submit" class="btn mjks"
                        style="color:#FFFFFF; height:30px; width:auto;">
                        <i class="fa fa-plus"></i>ADD</button>
                    <button id="on" type="button" data-toggle="modal" data-target="#popup5" class="btn mjks"
                        style="color:#FFFFFF; height:30px; width:auto;"> <i class="fa fa-gear"></i>Manage</button>

                </div>
            </form>
        </div>

        <!-- ================================================Grade Model===================================== -->
        <div class="modal" id="popup5" tabindex="-1" role="dialog" aria-labelledby="smallModalHead"
            aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal"><span
                                aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                        <h4 class="modal-title" id="H4">Added Grade</h4>
                    </div>
                    <div class="modal-body" style="height:30%;padding: 10px;">
                        <div class="panel-body" style="margin-top:5px; margin-bottom:15px;">
                            <table class="table datatable">
                                <thead>
                                    <tr>
                                        <th>Sr. No.</th>

                                        <th>Added Grade</th>

                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $grade; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grades): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>

                                            <td><?php echo e($grades->grade); ?></td>

                                            <td>

                                                <button data-toggle="modal" data-target="#popup15"
                                                    value="<?php echo e($grades->id); ?>" grade_name=<?php echo e($grades->grade); ?>

                                                    style="background-color:#3399ff; border:none; max-height:25px; margin-top:-5px; margin-bottom:-5px;"
                                                    type="button" class="btn btn-info editbtn_grade"
                                                    data-toggle="tooltip" data-placement="top" title="Edit"><i
                                                        class="fa fa-edit" style="margin-left:5px;"></i></button>
                                                <a href="<?php echo e(route('grade_destroy', $grades->id)); ?>"> <button
                                                        style="background-color:#ff0000; border:none; max-height:25px; margin-top:-5px; margin-bottom:-5px;"
                                                        type="button" class="btn btn-info" data-toggle="tooltip"
                                                        data-placement="top" title="Delete"><i class="fa fa-trash-o"
                                                            style="margin-left:5px;"></i></button>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="modal-footer" style="border: none !important; background-color: #FFF !important;">
                        <!-- <button type="button" class="btn btn-default" data-dismiss="modal">Close</button> -->
                    </div>
                </div>
            </div>
        </div>

        <div class="modal" id="popup15" tabindex="-1" role="dialog" aria-labelledby="smallModalHead"
            aria-hidden="true">
            <div class="modal-dialog modal-sm">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal"><span
                                aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                        <h4 class="modal-title" id="H4">Update Grade</h4>
                    </div>
                    <div class="modal-body" style="height:30%;padding: 10px;">
                        <div class="panel-body" style="margin-top:5px; margin-bottom:15px;">
                            <form action="<?php echo e(route('update_grade')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" id="grade_id" name="grade_id">
                                <div class="col-md-12">

                                    <div class="col-md-6">
                                        <label class="control-label"> Grade<font color="#FF0000">*</font></label>
                                        <input type="text" class="form-control" id="grade" name="grade"
                                            placeholder="" />
                                    </div>

                                    <div class="col-md-6" style="margin-top:15px;padding-left: 10px;">
                                        <button id="on" type="submit" class="btn mjks"
                                            style="color:#FFFFFF; height:30px; width:auto;"> <i
                                                class="fa fa-plus"></i>Update</button>


                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="modal-footer" style="border: none !important; background-color: #FFF !important;">
                        <!-- <button type="button" class="btn btn-default" data-dismiss="modal">Close</button> -->
                    </div>
                </div>
            </div>
        </div>
        <!-- ============================================================End Grade Model========================= -->


        <div class="col-md-12">
            <img src="<?php echo e(asset('img/line.png')); ?>" width="100%" />
        </div>
        <form action="<?php echo e(route('section_store')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="col-md-12" style="margin-top: 2vh;">
                <div class="col-md-1">
                    <label class="control-label">Select Grade<font color="#FF0000">*</font></label>
                    <select class="form-control select" data-live-search="true" name="grade_id">
                        <option value="">Select</option>
                        <?php $__currentLoopData = $grade; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grade1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($grade1->id); ?>"><?php echo e($grade1->grade); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </select>
                </div>

                <div class="col-md-1">
                    <label class="control-label">Add Section<font color="#FF0000">*</font></label>
                    <input type="text" class="form-control" name="section_name" placeholder="" />
                </div>

                <div class="col-md-2" style="margin-top:15px;">
                    <button id="on" type="submit" class="btn mjks"
                        style="color:#FFFFFF; height:30px; width:auto;">
                        <i class="fa fa-plus"></i>ADD</button>
                    <button id="on" type="button" data-toggle="modal" data-target="#popup6" class="btn mjks"
                        style="color:#FFFFFF; height:30px; width:auto;"> <i class="fa fa-gear"></i>Manage</button>

                </div>
        </form>

        <div class="modal" id="popup6" tabindex="-1" role="dialog" aria-labelledby="smallModalHead"
            aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal"><span
                                aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                        <h4 class="modal-title" id="H4">Added Sections</h4>
                    </div>
                    <div class="modal-body" style="height:30%;padding: 10px;">
                        <div class="panel-body" style="margin-top:5px; margin-bottom:15px;">
                            <table class="table datatable">
                                <thead>
                                    <tr>
                                        <th>Sr. No.</th>

                                        <th>Selected Grade</th>
                                        <th>Added Section</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $section; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sections): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>

                                            <td><?php echo e($sections->grade_name->grade); ?></td>
                                            <td><?php echo e($sections->section_name); ?></td>
                                            <td>

                                                <button data-toggle="modal" data-target="#popup16"
                                                    value="<?php echo e($sections->id); ?>" grade_id="<?php echo e($sections->grade_id); ?>"
                                                    section_name="<?php echo e($sections->section_name); ?>"
                                                    style="background-color:#3399ff; border:none; max-height:25px; margin-top:-5px; margin-bottom:-5px;"
                                                    type="button" class="btn btn-info editbtn_section"
                                                    data-toggle="tooltip" data-placement="top" title="Edit"><i
                                                        class="fa fa-edit" style="margin-left:5px;"></i></button>
                                                <a href="<?php echo e(route('section_destroy', $sections->id)); ?>"> <button
                                                        style="background-color:#ff0000; border:none; max-height:25px; margin-top:-5px; margin-bottom:-5px;"
                                                        type="button" class="btn btn-info" data-toggle="tooltip"
                                                        data-placement="top" title="Delete"><i class="fa fa-trash-o"
                                                            style="margin-left:5px;"></i></button>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="modal-footer" style="border: none !important; background-color: #FFF !important;">
                        <!-- <button type="button" class="btn btn-default" data-dismiss="modal">Close</button> -->
                    </div>
                </div>
            </div>
        </div>

        <div class="modal" id="popup16" tabindex="-1" role="dialog" aria-labelledby="smallModalHead"
            aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <form action="<?php echo e(route('update_section')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" id="section_id" name="section_id">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal"><span
                                    aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                            <h4 class="modal-title" id="H4">Update Sections</h4>
                        </div>
                        <div class="modal-body" style="height:30%;padding: 10px;">
                            <div class="panel-body" style="margin-top:5px; margin-bottom:15px;">
                                <div class="col-md-12">

                                    <div class="col-md-2" style="margin-right: 5px;">
                                        <label class="control-label">Select Grade<font color="#FF0000">*</font></label>
                                        <select class="form-control select" data-live-search="true" name="grade_id"
                                            id="grade_id_option">
                                            <option value="">Select</option>
                                            <?php $__currentLoopData = $grade; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grade1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($grade1->id); ?>"><?php echo e($grade1->grade); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </select>
                                    </div>
                                    
                                    <div class="col-md-2">
                                        <label class="control-label">Add Section<font color="#FF0000">*</font></label>
                                        <input type="text" class="form-control" id="section_name" name="section_name"
                                            placeholder="" />
                                    </div>

                                    <div class="col-md-6" style="margin-top:15px;padding-left: 10px;">
                                        <button id="on" type="submit" class="btn mjks"
                                            style="color:#FFFFFF; height:30px; width:auto;"> <i
                                                class="fa fa-plus"></i>Update</button>


                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                    <div class="modal-footer" style="border: none !important; background-color: #FFF !important;">
                        <!-- <button type="button" class="btn btn-default" data-dismiss="modal">Close</button> -->
                    </div>
                </div>
            </div>
        </div>
        <!-- ======================================End section model================================== -->

        <form action="<?php echo e(route('prop_store')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="col-md-2">
                <label class="control-label">Add Prop Type<font color="#FF0000">*</font></label>
                <input type="text" class="form-control" name="prop_name" placeholder="" />
            </div>

            <div class="col-md-2" style="margin-top:15px;">
                <button id="on" type="sub,it" class="btn mjks" style="color:#FFFFFF; height:30px; width:auto;">
                    <i class="fa fa-plus"></i>ADD</button>
                <button id="on" type="button" data-toggle="modal" data-target="#popup7" class="btn mjks"
                    style="color:#FFFFFF; height:30px; width:auto;"> <i class="fa fa-gear"></i>Manage</button>

            </div>

        </form>

        <div class="modal" id="popup7" tabindex="-1" role="dialog" aria-labelledby="smallModalHead"
            aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal"><span
                                aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                        <h4 class="modal-title" id="H4">Added Prop Types</h4>
                    </div>
                    <div class="modal-body" style="height:30%;padding: 10px;">
                        <div class="panel-body" style="margin-top:5px; margin-bottom:15px;">
                            <table class="table datatable">
                                <thead>
                                    <tr>
                                        <th>Sr. No.</th>

                                        <th>Added Prop Types</th>

                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $prop; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $props): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>

                                            <td><?php echo e($props->prop_name); ?></td>

                                            <td>

                                                <button data-toggle="modal" data-target="#popup17"
                                                    value="<?php echo e($props->id); ?>" prop_name="<?php echo e($props->prop_name); ?>"
                                                    style="background-color:#3399ff; border:none; max-height:25px; margin-top:-5px; margin-bottom:-5px;"
                                                    type="button" class="btn btn-info editbtn_prop"
                                                    data-toggle="tooltip" data-placement="top" title="Edit"><i
                                                        class="fa fa-edit" style="margin-left:5px;"></i></button>
                                                <a href="<?php echo e(route('prop_destroy', $props->id)); ?>"> <button
                                                        style="background-color:#ff0000; border:none; max-height:25px; margin-top:-5px; margin-bottom:-5px;"
                                                        type="button" class="btn btn-info" data-toggle="tooltip"
                                                        data-placement="top" title="Delete"><i class="fa fa-trash-o"
                                                            style="margin-left:5px;"></i></button>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="modal-footer" style="border: none !important; background-color: #FFF !important;">
                        <!-- <button type="button" class="btn btn-default" data-dismiss="modal">Close</button> -->
                    </div>
                </div>
            </div>
        </div>

        <div class="modal" id="popup17" tabindex="-1" role="dialog" aria-labelledby="smallModalHead"
            aria-hidden="true">
            <div class="modal-dialog modal-sm">
                <div class="modal-content">
                    <div class="modal-header">

                        <button type="button" class="close" data-dismiss="modal"><span
                                aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                        <h4 class="modal-title" id="H4">Update Prop Type</h4>
                    </div>
                    <div class="modal-body" style="height:30%;padding: 10px;">
                        <form action="<?php echo e(route('update_prop')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" id="prop_id" name="prop_id">
                            <div class="panel-body" style="margin-top:5px; margin-bottom:15px;">
                                <div class="col-md-12">

                                    <div class="col-md-6">
                                        <label class="control-label"> Add Prop Types<font color="#FF0000">*</font></label>
                                        <input type="text" class="form-control" id="prop_name" name="prop_name"
                                            placeholder="" />
                                    </div>

                                    <div class="col-md-6" style="margin-top:15px;padding-left: 10px;">
                                        <button id="on" type="submit" class="btn mjks"
                                            style="color:#FFFFFF; height:30px; width:auto;"> <i
                                                class="fa fa-plus"></i>Update</button>


                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="modal-footer" style="border: none !important; background-color: #FFF !important;">
                        <!-- <button type="button" class="btn btn-default" data-dismiss="modal">Close</button> -->
                    </div>
                </div>
            </div>
        </div>
        <!-- ======================================End prop model================================== -->

    </div>
    <div class="col-md-12">
        <img src="<?php echo e(asset('img/line.png')); ?>" width="100%" />
    </div>
    <form action="<?php echo e(route('vendor_store')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="col-md-12" style="margin-top: 2vh;">
            <div class="col-md-2">
                <label class="control-label">Add Vendor Name<font color="#FF0000">*</font></label>
                <input type="text" class="form-control" name="vendor_name" placeholder="" />
            </div>
            <div class="col-md-1">
                <label class="control-label">Mobile No.<font color="#FF0000">*</font></label>
                <input type="text" class="form-control" name="mobile" maxlength="10" placeholder="" />
            </div>
            <div class="col-md-2" style="margin-right: 5px;">
                <label class="control-label">Select City<font color="#FF0000">*</font></label>
                <select class="form-control select" data-live-search="true" name="city_id">
                    <option value="">Select</option>
                    <?php $__currentLoopData = $city; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($city1->id); ?>"><?php echo e($city1->city_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </select>
            </div>
            <div class="col-md-2">
                <label class="control-label">Email<font color="#FF0000">*</font></label>
                <input type="text" class="form-control" name="email" placeholder="" />
            </div>

            <div class="col-md-2" style="margin-top:15px;">
                <button id="on" type="submit" class="btn mjks" style="color:#FFFFFF; height:30px; width:auto;">
                    <i class="fa fa-plus"></i>ADD</button>
                <button id="on" type="button" data-toggle="modal" data-target="#popup9" class="btn mjks"
                    style="color:#FFFFFF; height:30px; width:auto;"> <i class="fa fa-gear"></i>Manage</button>

            </div>

        </div>
    </form>

    <div class="modal" id="popup9" tabindex="-1" role="dialog" aria-labelledby="smallModalHead"
        aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal"><span
                            aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                    <h4 class="modal-title" id="H4">Added Vendor</h4>
                </div>
                <div class="modal-body" style="height:30%;padding: 10px;">
                    <div class="panel-body" style="margin-top:5px; margin-bottom:15px;">
                        <table class="table datatable">
                            <thead>

                                <tr>
                                    <th>Sr. No.</th>

                                    <th>Added Vendor Name</th>
                                    <th>Mobile No.</th>
                                    <th>City</th>
                                    <th>Email</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $vendor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendors): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($vendors->vendor_name); ?></td>
                                        <td><?php echo e($vendors->mobile); ?></td>
                                        <td><?php echo e($vendors->cityName->city_name); ?></td>
                                        <td><?php echo e($vendors->email); ?></td>
                                        <td>

                                            <button data-toggle="modal" data-target="#popup18"
                                                value="<?php echo e($vendors->id); ?>" vendor_name="<?php echo e($vendors->vendor_name); ?>"
                                                mobile="<?php echo e($vendors->mobile); ?>" vendor_city_id="<?php echo e($vendors->city_id); ?>"
                                                email="<?php echo e($vendors->email); ?>"
                                                style="background-color:#3399ff; border:none; max-height:25px; margin-top:-5px; margin-bottom:-5px;"
                                                type="button" class="btn btn-info editbtn_vendor" data-toggle="tooltip"
                                                data-placement="top" title="Edit"><i class="fa fa-edit"
                                                    style="margin-left:5px;"></i></button>
                                            <a href="<?php echo e(route('vendor_destroy', $vendors->id)); ?>"> <button
                                                    style="background-color:#ff0000; border:none; max-height:25px; margin-top:-5px; margin-bottom:-5px;"
                                                    type="button" class="btn btn-info" data-toggle="tooltip"
                                                    data-placement="top" title="Delete"><i class="fa fa-trash-o"
                                                        style="margin-left:5px;"></i></button>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="modal-footer" style="border: none !important; background-color: #FFF !important;">
                    <!-- <button type="button" class="btn btn-default" data-dismiss="modal">Close</button> -->
                </div>
            </div>
        </div>
    </div>

    <div class="modal" id="popup18" tabindex="-1" role="dialog" aria-labelledby="smallModalHead"
        aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal"><span
                            aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                    <h4 class="modal-title" id="H4">Update Vendor</h4>
                </div>
                <div class="modal-body" style="height:30%;padding: 10px;">
                    <div class="panel-body" style="margin-top:5px; margin-bottom:15px;">
                        <div class="col-md-12">
                            <form action="<?php echo e(route('update_vendor')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" id="vendor_id" name="vendor_id">
                                <div class="col-md-2" style="margin-right: 5px;">
                                    <label class="control-label">Add Vendor Name<font color="#FF0000">*</font></label>
                                    <input type="text" class="form-control" id="vendor_name" name="vendor_name"
                                        placeholder="" />
                                </div>
                                <div class="col-md-2" style="margin-right: 5px;">
                                    <label class="control-label">Mobile No.<font color="#FF0000">*</font></label>
                                    <input type="text" class="form-control" id="mobile" name="mobile"
                                        maxlength="10" placeholder="" />
                                </div>
                                <div class="col-md-2" style="margin-right: 5px;">
                                    <label class="control-label">Select City<font color="#FF0000">*</font></label>
                                    <select class="form-control select" data-live-search="true" id="vendor_city_id"
                                        name="city_id">
                                        <option value="">Select</option>
                                        <?php $__currentLoopData = $city; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($city1->id); ?>"><?php echo e($city1->city_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </select>
                                </div>
                                <div class="col-md-2" style="margin-right: 5px;">
                                    <label class="control-label">Email<font color="#FF0000">*</font></label>
                                    <input type="text" class="form-control" id="email" name="email"
                                        placeholder="" />
                                </div>

                                <div class="col-md-2" style="margin-top:15px;padding-left: 10px;">
                                    <button id="on" type="submit" class="btn mjks"
                                        style="color:#FFFFFF; height:30px; width:auto;"> <i
                                            class="fa fa-plus"></i>Update</button>


                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="modal-footer" style="border: none !important; background-color: #FFF !important;">
                    <!-- <button type="button" class="btn btn-default" data-dismiss="modal">Close</button> -->
                </div>
            </div>
        </div>
    </div>
    <!-- ================================================end of vondor======================== -->


    <div class="col-md-12">
        <img src="<?php echo e(asset('img/line.png')); ?>" width="100%" />
    </div>
    <div class="col-md-12">
        <h5 style="font-weight: bold;text-align: center;">Fitness Assessment</h5>
        <form action="<?php echo e(route('test_component_store')); ?>" method="post">
            <?php echo csrf_field(); ?>
            
        <div class="col-md-2">
            <label class="control-label">Name of Test Components<font color="#FF0000">*</font></label>
            <input type="text" class="form-control" name="name_of_test_components" placeholder="" />
        </div>

        <div class="col-md-2" style="margin-top:15px;">
            <button id="on" type="submit" class="btn mjks" style="color:#FFFFFF; height:30px; width:auto;">
                <i class="fa fa-plus"></i>ADD</button>
            <button id="on" type="button" data-toggle="modal" data-target="#popup10" class="btn mjks"
                style="color:#FFFFFF; height:30px; width:auto;"> <i class="fa fa-gear"></i>Manage</button>

        </div>
    </form>

    <div class="modal" id="popup10" tabindex="-1" role="dialog" aria-labelledby="smallModalHead"
        aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal"><span
                            aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                    <h4 class="modal-title" id="H4">Added Fitness Assessment</h4>
                </div>
                <div class="modal-body" style="height:30%;padding: 10px;">
                    <div class="panel-body" style="margin-top:5px; margin-bottom:15px;">
                        <table class="table datatable">
                            <thead>
                                <tr>
                                    <th>Sr. No.</th>

                                    
                                    <th>Name of Test</th>

                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $TestComponent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $TestComponents): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    
                                    <td><?php echo e($TestComponents->name_of_test_components); ?></td>
                                    

                                    <td>

                                        <button data-toggle="modal" data-target="#popup19" value="<?php echo e($TestComponents->id); ?>"
                                            name_of_test_components="<?php echo e($TestComponents->name_of_test_components); ?>" style="background-color:#3399ff; border:none; max-height:25px; margin-top:-5px; margin-bottom:-5px;"
                                            type="button" class="btn btn-info editbtn_testcomponent" data-toggle="tooltip"
                                            data-placement="top" title="Edit"><i class="fa fa-edit"
                                                style="margin-left:5px;"></i></button>
                                      <a href="<?php echo e(route('test_component_destroy',$TestComponents->id)); ?>">  <button
                                            style="background-color:#ff0000; border:none; max-height:25px; margin-top:-5px; margin-bottom:-5px;"
                                            type="button" class="btn btn-info" data-toggle="tooltip"
                                            data-placement="top" title="Delete"><i class="fa fa-trash-o"
                                                style="margin-left:5px;"></i></button>
                                      </a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="modal-footer" style="border: none !important; background-color: #FFF !important;">
                    <!-- <button type="button" class="btn btn-default" data-dismiss="modal">Close</button> -->
                </div>
            </div>
        </div>
    </div>

    <div class="modal" id="popup19" tabindex="-1" role="dialog" aria-labelledby="smallModalHead"
        aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal"><span
                            aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                    <h4 class="modal-title" id="H4">Update Fitness Assessment</h4>
                </div>
                <div class="modal-body" style="height:30%;padding: 10px;">
                    <div class="panel-body" style="margin-top:5px; margin-bottom:15px;">
                        <div class="col-md-12">
                            <form action="<?php echo e(route('update_test_component')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" id="testcomponent_id" name="testcomponent_id">
                            

                            <div class="col-md-3">
                                <label class="control-label">Name of Test Components<font color="#FF0000">*</font>
                                </label>
                                <input type="text" class="form-control" id="name_of_test_components" name="name_of_test_components" placeholder="" />
                            </div>

                            <div class="col-md-4" style="margin-top:15px;padding-left: 10px;">
                                <button id="on" type="submit" class="btn mjks"
                                    style="color:#FFFFFF; height:30px; width:auto;"> <i
                                        class="fa fa-plus"></i>Update</button>


                            </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="modal-footer" style="border: none !important; background-color: #FFF !important;">
                    <!-- <button type="button" class="btn btn-default" data-dismiss="modal">Close</button> -->
                </div>
            </div>
        </div>
    </div>

    <!-- ================================================end of testcomponent======================== -->

    <form action="<?php echo e(route('fitness_store')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="col-md-1">
            <label class="control-label">Select Grade<font color="#FF0000">*</font></label>
            <select class="form-control select" data-live-search="true" name="grade_id">
                <option value="">Select</option>
                <?php $__currentLoopData = $grade; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grade2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($grade2->id); ?>"><?php echo e($grade2->grade); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </select>
        </div>
        <div class="col-md-1" style="margin-right: 5px;">
            <label class="control-label">Select Test<font color="#FF0000">*</font></label>
            <select class="form-control select" data-live-search="true"
                name="test_id">
                <option value="">Select</option>
                <?php $__currentLoopData = $TestComponent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $TestComponent2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($TestComponent2->id); ?>"><?php echo e($TestComponent2->name_of_test_components); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </select>
        </div>
        <div class="col-md-2">
            <label class="control-label">Test Battery<font color="#FF0000">*</font></label>
            <input type="text" class="form-control" name="test_battery" placeholder="" />
        </div>

        <div class="col-md-2" style="margin-top:15px;">
            <button id="on" type="submit" class="btn mjks" style="color:#FFFFFF; height:30px; width:auto;">
                <i class="fa fa-plus"></i>ADD</button>
            <button id="on" type="button" data-toggle="modal" data-target="#popup11" class="btn mjks"
                style="color:#FFFFFF; height:30px; width:auto;"> <i class="fa fa-gear"></i>Manage</button>

        </div>
    </form>

    </div>

<div class="modal" id="popup11" tabindex="-1" role="dialog" aria-labelledby="smallModalHead"
aria-hidden="true">
<div class="modal-dialog modal-lg">
    <div class="modal-content">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal"><span
                    aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
            <h4 class="modal-title" id="H4">Added Fitness Assessment</h4>
        </div>
        <div class="modal-body" style="height:30%;padding: 10px;">
            <div class="panel-body" style="margin-top:5px; margin-bottom:15px;">
                <table class="table datatable">
                    <thead>
                        <tr>
                            <th>Sr. No.</th>
                            <th>Selected Grade</th>
                            <th>Selected Test</th>
                            <th>Test Battery</th>

                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $fitness; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fitnesss): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($fitnesss->grade_name->grade); ?></td>
                            <td><?php echo e($fitnesss->test_name->name_of_test_components); ?></td>
                            <td><?php echo e($fitnesss->test_battery); ?></td>
                            <td>

                                <button data-toggle="modal" data-target="#popup20" value="<?php echo e($fitnesss->id); ?>"
                                  fitness_test_id="<?php echo e($fitnesss->test_id); ?>" fitness_grade_id="<?php echo e($fitnesss->grade_id); ?>" fitness= "<?php echo e($fitnesss->test_battery); ?>" style="background-color:#3399ff; border:none; max-height:25px; margin-top:-5px; margin-bottom:-5px;"
                                    type="button" class="btn btn-info editbtn_fitness" data-toggle="tooltip"
                                    data-placement="top" title="Edit"><i class="fa fa-edit"
                                        style="margin-left:5px;"></i></button>
                              <a href="<?php echo e(route('fitness_destroy',$fitnesss->id)); ?>">  <button
                                    style="background-color:#ff0000; border:none; max-height:25px; margin-top:-5px; margin-bottom:-5px;"
                                    type="button" class="btn btn-info" data-toggle="tooltip"
                                    data-placement="top" title="Delete"><i class="fa fa-trash-o"
                                        style="margin-left:5px;"></i></button>
                              </a>
                            </td>
                        </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            </div>
        </div>
        <div class="modal-footer" style="border: none !important; background-color: #FFF !important;">
            <!-- <button type="button" class="btn btn-default" data-dismiss="modal">Close</button> -->
        </div>
    </div>
</div>
</div>

<div class="modal" id="popup20" tabindex="-1" role="dialog" aria-labelledby="smallModalHead"
aria-hidden="true">
<div class="modal-dialog modal-lg">
    <div class="modal-content">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal"><span
                    aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
            <h4 class="modal-title" id="H4">Update Fitness Assessment</h4>
        </div>
        <form action="<?php echo e(route('update_fitness')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <input type="hidden" id="fitness_id" name="fitness_id">
        <div class="modal-body" style="height:30%;padding: 10px;">
            <div class="panel-body" style="margin-top:5px; margin-bottom:15px;">
                <div class="col-md-12">
                    <div class="col-md-2">
                        <label class="control-label">Select Grade<font color="#FF0000">*</font></label>
                        <select class="form-control select" data-live-search="true" id="fitness_grade_id" name="grade_id">
                            <option value="">Select</option>
                            <?php $__currentLoopData = $grade; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grade2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($grade2->id); ?>"><?php echo e($grade2->grade); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            
                        </select>
                    </div>
                    <div class="col-md-2" style="margin-right: 5px;">
                        <label class="control-label">Select Test<font color="#FF0000">*</font></label>
                        <select class="form-control select" data-live-search="true"
                            name="test_id" id="fitness_test_id">
                            <option value="">Select</option>
                            <?php $__currentLoopData = $TestComponent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $TestComponent2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($TestComponent2->id); ?>"><?php echo e($TestComponent2->name_of_test_components); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
                        </select>
                    </div>
                    <div class="col-md-2" style="margin-right: 5px;">
                        <label class="control-label">Test Battery<font color="#FF0000">*</font></label>
                        <input type="text" class="form-control" name="test_battery" id="fitness" placeholder="" />
                    </div>
                    <div class="col-md-2" style="margin-top:15px;padding-left: 10px;">
                        <button id="on" type="submit" class="btn mjks"
                            style="color:#FFFFFF; height:30px; width:auto;"> <i
                                class="fa fa-plus"></i>Update</button>


                    </div>
                </div>
            </form>
            </div>
        </div>
        <div class="modal-footer" style="border: none !important; background-color: #FFF !important;">
            <!-- <button type="button" class="btn btn-default" data-dismiss="modal">Close</button> -->
        </div>
    </div>
</div>
</div>

    <!-- ================================================end of fitness==============================-->

    <div class="col-md-12">
        <img src="<?php echo e(asset('img/line.png')); ?>" width="100%" />
    </div>
    <div class="col-md-12">
        <h5 style="font-weight: bold;text-align: center;">Skills Assessment</h5>

            <form action="<?php echo e(route('skill_store')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="col-md-2">
                    <label class="control-label">Select Grade<font color="#FF0000">*</font></label>
                    <select class="form-control select" data-live-search="true" 
                        name="grade_id">
                        <option value="">Select</option>
                        <?php $__currentLoopData = $grade; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grade3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($grade3->id); ?>"><?php echo e($grade3->grade); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </select>
                </div>
                <div class="col-md-2">
                    <label class="control-label">Add Skills<font color="#FF0000">*</font></label>
                    <input type="text" class="form-control" name="skill" placeholder="" />
                </div>

                <div class="col-md-2" style="margin-top:15px;">
                    <button id="on" type="submit" class="btn mjks"
                        style="color:#FFFFFF; height:30px; width:auto;">
                        <i class="fa fa-plus"></i>ADD</button>
                    <button id="on" type="button" data-toggle="modal" data-target="#popup12"
                        class="btn mjks" style="color:#FFFFFF; height:30px; width:auto;"> <i
                            class="fa fa-gear"></i>Manage</button>

                </div>
            </form>


    </div>
    
        <div class="modal" id="popup12" tabindex="-1" role="dialog" aria-labelledby="smallModalHead"
            aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal"><span
                                aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                        <h4 class="modal-title" id="H4">Added Skills Assessment</h4>
                    </div>
                    <div class="modal-body" style="height:30%;padding: 10px;">
                        <div class="panel-body" style="margin-top:5px; margin-bottom:15px;">
                            <table class="table datatable">
                                <thead>
                                    <tr>
                                        <th>Sr. No.</th>
                                        <th>Selected Grade</th>
                                        <th>Skills</th>

                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($skill->grade_name->grade); ?></td>
                                            <td><?php echo e($skill->skill); ?></td>

                                            <td>

                                                <button data-toggle="modal" data-target="#popup21"
                                                    value="<?php echo e($skill->id); ?>"
                                                    skill_grade_id="<?php echo e($skill->grade_id); ?>"
                                                    skill_name="<?php echo e($skill->skill); ?>"
                                                    style="background-color:#3399ff; border:none; max-height:25px; margin-top:-5px; margin-bottom:-5px;"
                                                    type="button" class="btn btn-info editbtn_skill"
                                                    data-toggle="tooltip" data-placement="top" title="Edit"><i
                                                        class="fa fa-edit" style="margin-left:5px;"></i></button>
                                                <a href="<?php echo e(route('skill_destroy', $skill->id)); ?>"> <button
                                                        style="background-color:#ff0000; border:none; max-height:25px; margin-top:-5px; margin-bottom:-5px;"
                                                        type="button" class="btn btn-info" data-toggle="tooltip"
                                                        data-placement="top" title="Delete"><i class="fa fa-trash-o"
                                                            style="margin-left:5px;"></i></button>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="modal-footer" style="border: none !important; background-color: #FFF !important;">
                        <!-- <button type="button" class="btn btn-default" data-dismiss="modal">Close</button> -->
                    </div>
                </div>
            </div>
        </div>


        <div class="modal" id="popup21" tabindex="-1" role="dialog" aria-labelledby="smallModalHead"
            aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal"><span
                                aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                        <h4 class="modal-title" id="H4">Update Skills Assessment</h4>
                    </div>
                    <form action="<?php echo e(route('update_skill')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" id="skill_id" name="skill_id">
                    <div class="modal-body" style="height:30%;padding: 10px;">
                        <div class="panel-body" style="margin-top:5px; margin-bottom:15px;">
                            <div class="col-md-12">
                                <div class="col-md-2">
                                    <label class="control-label">Select Grade<font color="#FF0000">*</font></label>
                                    <select class="form-control select" data-live-search="true" id="skill_grade_id"
                                        name="grade_id">
                                        <option value="">Select</option>
                                        <?php $__currentLoopData = $grade; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grade3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($grade3->id); ?>"><?php echo e($grade3->grade); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                
                                    </select>
                                </div>
                                <div class="col-md-2">
                                    <label class="control-label">Add Skills<font color="#FF0000">*</font></label>
                                    <input type="text" class="form-control" id="skill_name" name="skill" placeholder="" />
                                </div>
                                <div class="col-md-2" style="margin-top:15px;padding-left: 10px;">
                                    <button id="on" type="submit" class="btn mjks"
                                        style="color:#FFFFFF; height:30px; width:auto;"> <i
                                            class="fa fa-plus"></i>Update</button>


                                </div>
                            </div>
                        </div>
                    </div>
                    </form>
                    <div class="modal-footer" style="border: none !important; background-color: #FFF !important;">
                        <!-- <button type="button" class="btn btn-default" data-dismiss="modal">Close</button> -->
                    </div>
                </div>
            </div>
        </div>
        <!-- ======================================End skill model================================== -->
    <div class="col-md-12">
        <img src="<?php echo e(asset('img/line.png')); ?>" width="100%" />
    </div>
    </div>

    </div>

    </div>


    <!-- START DEFAULT DATATABLE -->


    </div>



    </div>

    <!-- PAGE CONTENT WRAPPER -->


    </div>
    <!-- END PAGE CONTENT -->
    </div>
    <!-- END PAGE CONTAINER -->
    <!-- ============================Model for City====================================== -->

    <!-- ==========================End city Model===================================== -->
    <!-- ============================================Occupation Model================================= -->
    <div class="modal" id="popup4" tabindex="-1" role="dialog" aria-labelledby="smallModalHead"
        aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal"><span
                            aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                    <h4 class="modal-title" id="H4">Added Category</h4>
                </div>
                <div class="modal-body" style="height:30%;padding: 10px;">
                    <div class="panel-body" style="margin-top:5px; margin-bottom:15px;">
                        <table class="table datatable">
                            <thead>
                                <tr>
                                    <th>Sr. No.</th>

                                    <th>Added Category</th>

                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>1</td>

                                    <td>Category1</td>

                                    <td>

                                        <button
                                            style="background-color:#3399ff; border:none; max-height:25px; margin-top:-5px; margin-bottom:-5px;"
                                            type="button" class="btn btn-info" data-toggle="tooltip"
                                            data-placement="top" title="Edit"><i class="fa fa-edit"
                                                style="margin-left:5px;"></i></button>
                                        <button
                                            style="background-color:#ff0000; border:none; max-height:25px; margin-top:-5px; margin-bottom:-5px;"
                                            type="button" class="btn btn-info" data-toggle="tooltip"
                                            data-placement="top" title="Delete"><i class="fa fa-trash-o"
                                                style="margin-left:5px;"></i></button>
                                    </td>
                                </tr>


                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="modal-footer" style="border: none !important; background-color: #FFF !important;">
                    <!-- <button type="button" class="btn btn-default" data-dismiss="modal">Close</button> -->
                </div>
            </div>
        </div>
    </div>

    <!-- =============================================================End Model========================== -->

    <!-- =========================================sale status model===================== -->

    <!-- =========================================Transaction model===================== -->
    <div class="modal" id="popup7" tabindex="-1" role="dialog" aria-labelledby="smallModalHead"
        aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal"><span
                            aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                    <h4 class="modal-title" id="H4">Added Prop Types</h4>
                </div>
                <div class="modal-body" style="height:30%;padding: 10px;">
                    <div class="panel-body" style="margin-top:5px; margin-bottom:15px;">
                        <table class="table datatable">
                            <thead>
                                <tr>
                                    <th>Sr. No.</th>

                                    <th>Added Prop Types</th>

                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>1</td>

                                    <td>Rope</td>

                                    <td>

                                        <button data-toggle="modal" data-target="#popup17"
                                            style="background-color:#3399ff; border:none; max-height:25px; margin-top:-5px; margin-bottom:-5px;"
                                            type="button" class="btn btn-info" data-toggle="tooltip"
                                            data-placement="top" title="Edit"><i class="fa fa-edit"
                                                style="margin-left:5px;"></i></button>
                                        <button
                                            style="background-color:#ff0000; border:none; max-height:25px; margin-top:-5px; margin-bottom:-5px;"
                                            type="button" class="btn btn-info" data-toggle="tooltip"
                                            data-placement="top" title="Delete"><i class="fa fa-trash-o"
                                                style="margin-left:5px;"></i></button>
                                    </td>
                                </tr>


                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="modal-footer" style="border: none !important; background-color: #FFF !important;">
                    <!-- <button type="button" class="btn btn-default" data-dismiss="modal">Close</button> -->
                </div>
            </div>
        </div>
    </div>
    <!-- ======================================End model================================== -->

    <!-- =========================================Vendor model===================== -->

    

  

    <!-- ======================================Skill============================================ -->

    <!-- ======================================End model================================== -->









    

   

    <div class="modal" id="popup21" tabindex="-1" role="dialog" aria-labelledby="smallModalHead"
        aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal"><span
                            aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                    <h4 class="modal-title" id="H4">Update Skills Assessment</h4>
                </div>
                <div class="modal-body" style="height:30%;padding: 10px;">
                    <div class="panel-body" style="margin-top:5px; margin-bottom:15px;">
                        <div class="col-md-12">
                            <div class="col-md-2" style="margin-right: 5px;">
                                <label class="control-label">Select Grade<font color="#FF0000">*</font></label>
                                <select class="form-control select" data-live-search="true">
                                    <option>Class A</option>
                                    <option>Class B</option>

                                </select>
                            </div>
                            <div class="col-md-2" style="margin-right: 5px;">
                                <label class="control-label">Add Skills<font color="#FF0000">*</font></label>
                                <input type="text" class="form-control" name="name" placeholder="" />
                            </div>
                            <div class="col-md-2" style="margin-top:15px;padding-left: 10px;">
                                <button id="on" type="button" class="btn mjks"
                                    style="color:#FFFFFF; height:30px; width:auto;"> <i
                                        class="fa fa-plus"></i>Update</button>


                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer" style="border: none !important; background-color: #FFF !important;">
                    <!-- <button type="button" class="btn btn-default" data-dismiss="modal">Close</button> -->
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    
    <script>
        $(document).ready(function() {

            $(document).on('click', '.editbtn_city', function() {
                var city_id = $(this).val();

                $('#popup13').modal('show');

                $('#city_name').val($(this).attr('city_name'));
                $('#city_id').val($(this).attr('value'));
            });

            $(document).on('click', '.editbtn_dsignation', function() {
                var designation_id = $(this).val();
                // console.log(designation_id);

                $('#popup14').modal('show');

                $('#designation').val($(this).attr('designation_name'));
                $('#designation_id').val($(this).attr('value'));
            });

            $(document).on('click', '.editbtn_grade', function() {
                var grade_id = $(this).val();
                // console.log(designation_id);
                $('#popup15').modal('show');

                $('#grade').val($(this).attr('grade_name'));
                $('#grade_id').val($(this).attr('value'));
            });

            $(document).on('click', '.editbtn_section', function() {
                var section_id = $(this).val();

                $('#popup16').modal('show');

                $('#section_name').val($(this).attr('section_name'));
                $('#grade_id_option').val($(this).attr('grade_id')).change();
                $('#section_id').val($(this).attr('value'));

            });

            $(document).on('click', '.editbtn_prop', function() {
                var prop_id = $(this).val();

                $('#popup17').modal('show');

                $('#prop_name').val($(this).attr('prop_name'));
                $('#prop_id').val($(this).attr('value'));

            });

            $(document).on('click', '.editbtn_vendor', function() {
                var vendor_id = $(this).val();

                $('#popup18').modal('show');

                $('#vendor_name').val($(this).attr('vendor_name'));
                $('#email').val($(this).attr('email'));
                $('#mobile').val($(this).attr('mobile'));
                $('#vendor_city_id').val($(this).attr('vendor_city_id')).change();
                $('#vendor_id').val($(this).attr('value'));

            });

            $(document).on('click', '.editbtn_testcomponent', function() {
                var testcomponent_id = $(this).val();

                $('#popup19').modal('show');

                $('#name_of_test_components').val($(this).attr('name_of_test_components'));
                // $('#test_id').val($(this).attr('test_id')).change();
                $('#testcomponent_id').val($(this).attr('value'));

            });

            $(document).on('click', '.editbtn_fitness', function() {
                var fitness_id = $(this).val();

                $('#popup20').modal('show');
                
                $('#fitness').val($(this).attr('fitness')).change();
                $('#fitness_test_id').val($(this).attr('fitness_test_id')).change();
                $('#fitness_grade_id').val($(this).attr('fitness_grade_id')).change();
                $('#fitness_id').val($(this).attr('value'));

            });

            $(document).on('click', '.editbtn_skill', function() {
                var skill_id = $(this).val();

                $('#popup21').modal('show');
                
                $('#skill_name').val($(this).attr('skill_name')).change();
                $('#skill_grade_id').val($(this).attr('skill_grade_id')).change();
                $('#skill_id').val($(this).attr('value'));

            });


        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\sportschamp1\resources\views/masters/all_master.blade.php ENDPATH**/ ?>