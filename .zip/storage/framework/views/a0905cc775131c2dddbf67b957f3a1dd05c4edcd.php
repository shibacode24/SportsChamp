<div class="col-md-12" style="margin-top:5px;">
    <label
        style="color:#000; background-color:#FFCC00; width:7%; height:25px; padding-top:5px;margin-top: 1vh;"
        align="center"><span class="fa fa-desktop"></span> <strong>Masters</strong></label>

    <!-- <label style="color:#db1212f3;font-size: large;" title="Dashboard"><i class="fa fa-desktop"></i></label> -->
    <a href="<?php echo e(route('index')); ?>"> <button id="on" type="button" class="btn mjks"
            style="color:#FFFFFF; height:30px; width:auto;background-color: #993800;"><i
                class="fa fa-plus"></i>Masters</button>
    </a>
    <a href="<?php echo e(route('school')); ?>"> <button id="on" type="button" class="btn mjks"
            style="color:#FFFFFF; height:30px; width:auto;background-color: #8dd510; "><i
                class="fa fa-graduation-cap"></i>Manage Schools </button>
        <a href="<?php echo e(route('index')); ?>"> <button id="on" type="button" class="btn mjks"
                style="color:#FFFFFF; height:30px; width:auto;background-color: #0cb733; "><i
                    class="fa fa-users"></i>Manage Students</button>
        </a> </a>

    <a href="<?php echo e(route('employee')); ?>"> <button id="on" type="button" class="btn mjks"
            style="color:#FFFFFF; height:30px; width:auto;background-color: #540338; "><i
                class="fa fa-user"></i>Manage Employees</button>
    </a>
    <a href="<?php echo e(route('manage_prop')); ?>"> <button id="on" type="button" class="btn mjks"
            style="color:#FFFFFF; height:30px; width:auto;background-color: #1ab9bc;"><i
                class="fa fa-trophy"></i>Manage Props</button>
    </a>
    <a href="<?php echo e(route('ebook')); ?>"> <button id="on" type="button" class="btn mjks"
            style="color:#FFFFFF; height:30px; width:auto;background-color: #aa132c; "><i
                class="fa fa-book"></i>Manage E-books</button>
    </a>
    <a href="<?php echo e(route('blog')); ?>"> <button id="on" type="button" class="btn mjks"
            style="color:#FFFFFF; height:30px; width:auto;background-color: #076964;"><i
                class="fa fa-file-text"></i>Manage Blogs</button>
    </a>

    <a href="<?php echo e(route('manage_video')); ?>"> <button id="on" type="button" class="btn mjks"
            style="color:#FFFFFF; height:30px; width:auto;background-color: #cf6610; "><i
                class="fa fa-youtube"></i>Manage Videos</button>
    </a>
    <a href="<?php echo e(route('grade_card')); ?>"> <button id="on" type="button" class="btn mjks"
            style="color:#FFFFFF; height:30px; width:auto;background-color: #10cf89; "><i
                class="fa fa-edit"></i>Grade Card Action</button>
    </a>

</div><?php /**PATH C:\wamp64\www\webmedia-project\sportschamp2\resources\views/master.blade.php ENDPATH**/ ?>