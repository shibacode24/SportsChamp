<?php

namespace App\Models;
use App\Models\masters\Grade;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Activity extends Model
{
    use HasFactory;
    protected $table= 'activity';
    protected $fillable = [
        'grade_id',
        'category',
        'activity',
    ];
    public function grade_name()
    {
        return $this->hasOne(Grade::class, 'id', 'grade_id');
    }
}
