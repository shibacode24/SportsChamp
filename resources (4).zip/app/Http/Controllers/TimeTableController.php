<?php

namespace App\Http\Controllers;

use App\Models\masters\Employee;
use App\Models\masters\Grade;
use Illuminate\Http\Request;
use App\Models\TimeTable;

class TimeTableController extends Controller
{
    public function index()
    { 
        $emp = Employee::all();
        $grade = Grade::all();
      
        $time_table =1;
       
      
        return view('time_table',compact('time_table','emp','grade'));
    }

    public function time_table_store(Request $request){
        //  dd($request->all());
        $request ->validate([
            'emp_id'=>'required',
            'days'=>'required',
            'grade_id'=>'required',
            'no_of_class'=>'required',    
        ]);
      
      $time_table = new TimeTable();
      $time_table->emp_id = $request->emp_id;
      $time_table->days= $request->days;
      $time_table->grade_id= $request->grade_id;
      $time_table->no_of_class= $request->no_of_class;

    //   echo json_encode($time_table);
    //   exit();

      $time_table->save(); 

        return redirect()->back()->with('success', 'TimeTable Added Successfully');
    }

    public function time_table_edit(Request $request)
        {
            $time_table_edit = TimeTable::find($request->id); 
           
        return view('edit_time_table',compact('time_table_edit'));

        }

    public function update_time_table(Request $request)
    {

        $time_table =  TimeTable::where('id',$request->id)->first();
        
        $time_table->emp_id = $request->emp_id;
        $time_table->days= $request->days;
        $time_table->grade_id= $request->grade_id;
        $time_table->no_of_class= $request->no_of_class;
       
        $time_table->save(); 

      
      
    return redirect(route('time_table'))->with('success', 'TimeTable Updated Successfully');
    }

    public function time_table_destroy($id){
        TimeTable::find($id)->delete();

        return redirect(route('time_table'))->with('success', 'TimeTable Deleted Successfully');
    }
}
