<div class="col-md-12" style="margin-top:5px;">
    <label
        style="color:#000; background-color:#FFCC00; width:7%; height:25px; padding-top:5px;margin-top: 1vh;"
        align="center"><span class="fa fa-desktop"></span> <strong>Masters</strong></label>

    <!-- <label style="color:#db1212f3;font-size: large;" title="Dashboard"><i class="fa fa-desktop"></i></label> -->
    <a href="{{route('index')}}"> <button id="on" type="button" class="btn mjks"
            style="color:#FFFFFF; height:30px; width:auto;background-color: #993800;"><i
                class="fa fa-plus"></i>Masters</button>
    </a>
    <a href="{{route('school')}}"> <button id="on" type="button" class="btn mjks"
            style="color:#FFFFFF; height:30px; width:auto;background-color: #8dd510; "><i
                class="fa fa-graduation-cap"></i>Manage Schools </button>
        <a href="{{route('student-import')}}"> <button id="on" type="button" class="btn mjks"
                style="color:#FFFFFF; height:30px; width:auto;background-color: #0cb733; "><i
                    class="fa fa-users"></i>Manage Students</button>
        </a> </a>

    <a href="{{route('employee')}}"> <button id="on" type="button" class="btn mjks"
            style="color:#FFFFFF; height:30px; width:auto;background-color: #540338; "><i
                class="fa fa-user"></i>Manage Employees</button>
    </a>
    <a href="{{route('manage_prop')}}"> <button id="on" type="button" class="btn mjks"
            style="color:#FFFFFF; height:30px; width:auto;background-color: #1ab9bc;"><i
                class="fa fa-trophy"></i>Manage Props</button>
    </a>
    <a href="{{route('ebook')}}"> <button id="on" type="button" class="btn mjks"
            style="color:#FFFFFF; height:30px; width:auto;background-color: #aa132c; "><i
                class="fa fa-book"></i>Manage E-books</button>
    </a>
    <a href="{{route('blog')}}"> <button id="on" type="button" class="btn mjks"
            style="color:#FFFFFF; height:30px; width:auto;background-color: #076964;"><i
                class="fa fa-file-text"></i>Manage Blogs</button>
    </a>

    <a href="{{route('manage_video')}}"> <button id="on" type="button" class="btn mjks"
            style="color:#FFFFFF; height:30px; width:auto;background-color: #cf6610; "><i
                class="fa fa-youtube"></i>Manage Videos</button>
    </a>
    <a href="{{route('grade_card')}}"> <button id="on" type="button" class="btn mjks"
        style="color:#FFFFFF; height:30px; width:auto;background-color: #10cf89; "><i
            class="fa fa-edit"></i>Grade Card Action</button>
</a>
<a href="{{route('sports_news')}}"> <button id="on" type="button" class="btn mjks"
    style="color:#FFFFFF; height:30px; width:auto;background-color: #e43abf; "><i
        class="fa fa-desktop"></i>Sports News</button>
</a>
<a href="{{route('yoga_meditation')}}"> <button id="on" type="button" class="btn mjks"
    style="color:#FFFFFF; height:30px; width:auto;background-color: #da2d36; "><i
        class="fa fa-child"></i>Yoga & Meditation</button>
</a>
<a href="{{route('live_class')}}"> <button id="on" type="button" class="btn mjks"
    style="color:#FFFFFF; height:30px; width:auto;background-color: #a30554; "><i
        class="fa fa-youtube-play"></i>Live Class</button>
</a>
<a href="{{route('sports_shop')}}"> <button id="on" type="button" class="btn mjks"
    style="color:#FFFFFF; height:30px; width:auto;background-color: #f1970e; "><i
        class="fa fa-shopping-cart"></i>Sports Shop</button>
</a>
<a href="{{route('event')}}"> <button id="on" type="button" class="btn mjks"
    style="color:#FFFFFF; height:30px; width:auto;background-color: #02412a; "><i
        class="fa fa-calendar-o"></i>Events</button>
</a>

</div>