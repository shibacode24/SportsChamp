@extends('layout')
@section('content')
@include('alert')

    <div class="page-content-wrap">
        <div class="row">
            <div class="col-md-2" style="margin-top: 2vh;"></div>
            <div class="col-md-8" style="margin-top: 2vh;">
                <form action="{{ route('time_table_store') }}" method="post" enctype="multipart/form-data">
                    @csrf
                    <table width="100%">
                        <tr style="height:30px;">
                            <th width="2%">Select Emp</th>
                            <th width="2%">Days</th>

                            <th width="1%">No. of Classes</th> 
                            <th width="1%">Select Grade</th> 

                            <th width="2%"></th>
                            {{-- <th width="2%"></th> --}}
                        </tr>


                        <tr>
                            <td style="padding: 2px;" width="1%">
                                <select class="form-control select" data-live-search="true" name="emp_id" id="emp">
                                    <option>Select</option>
                                    @foreach ($emp as $emps)
                                    <option value="{{$emps->id}}">{{$emps->name}}</option>  
                                    @endforeach
                                </select>
                            </td>

                            <td style="padding: 2px;" width="1%">
                                <select class="form-control select" data-live-search="true" name="days" id="days">
                                    <option value="monday">Monday</option>
                                    <option value="tuesday">Tuesday</option>
                                    <option value="wednesday">Wednesday</option>
                                    <option value="thursday">Thursday</option>
                                    <option value="friday">Friday</option>
                                    <option value="saturday">Saturday</option>
                                </select>
                            </td>

                            <td style="padding: 2px;" width="2%">
                                <input type="text" class="form-control" id="no_of_class" name="no_of_class" placeholder="" />
                            </td>

                            <td style="padding: 2px;" width="1%">
                                <select class="form-control select" data-live-search="true" id="grade_id" name="grade_id">
                                    <option>Select</option>
                                    @foreach ($grade as $grades)
                                    <option value="{{$grades->id}}">{{$grades->grade}}</option>  
                                    @endforeach
                                </select>
                            </td>
                           
                            {{-- <td>
                                <div class="col-md-2" style="padding:8px"><br>
                                    <button type="button" class="btn mjks add-row "><i
                                            class="fadeIn animated bx bx-plus" ></i>Add </button>
                                </div>
                               
                            </td> --}}
                            <td>
                                <button id="on" type="button" class="btn mjks"
                                style="color:#FFFFFF; height:30px; width:auto;background-color: #006699;"><i
                                    class="fa fa-floppy-o" aria-hidden="true"></i>
                                Submit</button> 
                            </td>
                        </tr>

                    </table>
                </form>
            </div>

        </div>
        <div class="row">
            <div class="col-md-2" style="margin-top: 2vh;"></div>
            <div class="col-md-8" style="margin-top:15px;">

                <!-- START DEFAULT DATATABLE -->

                <div class="panel-body" style="margin-top:5px; margin-bottom:15px;">
                    <table class="table datatable">
                        <thead>
                            <tr>
                                <th>Sr. No.</th>
                                <th>Title</th>
                                <th>Added Notification</th>
                                <th>Selected User</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        {{-- <tbody>
                            @foreach ($notification as $notifications)
                                <tr>
                                    <td>{{ $loop->iteration }}</td>
                                    <td>{{ $notifications->title }}</td>
                                    <td>{{ $notifications->notification }}</td>

                                    <td>{{ $notifications->select_user }}</td>


                                    <td>
                                        <a href="{{ route('notification_edit', $notifications->id) }}">
                                        <button
                                            style="background-color:#3399ff; border:none; max-height:25px; margin-top:-5px; margin-bottom:-5px;"
                                            type="button" class="btn btn-info" data-toggle="tooltip" data-placement="top"
                                            title="Edit"><i class="fa fa-edit" style="margin-left:5px;"></i></button>
                                        </a>
                                        <button
                                            onclick="openCustomModal('{{ route('notification_destroy', $notifications->id) }}')"
                                            id="customModal"
                                            style="background-color:#ff0000; border:none; max-height:25px; margin-top:-5px; margin-bottom:-5px;"
                                            type="button" class="btn btn-info" data-toggle="tooltip" data-placement="top"
                                            title="Delete"><i class="fa fa-trash-o" style="margin-left:5px;"></i></button>
                                    </td>
                                </tr>
                            @endforeach

                        </tbody> --}}
                    </table>
                </div>

                <!-- END DEFAULT DATATABLE -->


            </div>
        </div>

    </div>
@stop

@section('js')
<script>
    $(document).ready(function() {

        $(".add-row").click(function() {
                var emp = $('#emp').val();
                var grade_id = $('#grade_id').val();
                var days = $('#days').val();
                var no_of_class = $('#no_of_class').val();
                console.log(emp);
                console.log(grade_id);
                console.log(days);
                console.log(no_of_class);
                var markup =

                    '<tr><td><input type="hidden"  name="grade_id[]" required="" style="border:none; width: 100%;" value="' + grade_id +'"><td><input type="text"  required="" style="border:none; width: 100%;" value="' + grade_id +'"<input type="hidden"  name="emp[]" required="" style="border:none; width: 100%;" value = "'+emp+'"><input type="text" readonly name="days[]" required="" style="border:none; width: 100%;" value="' +
                        days.trim() +
                    '"></td><td><input type="text" readonly name="no_of_class[]" required="" style="border:none; width: 100%;" value="' +
                        no_of_class +
                    '"></td><td><button type="button" class="btn1 btn-outline-danger delete-row"><i class="bx bx-trash me-0"></i></button></td></tr>';

                $(".add_more").append(markup);
                $('#days').val('');
                $('#grade_id').val('');
                $('#no_of_class').val('');

            }

        )
        // Find and remove selected table rows
        $("tbody").delegate(".delete-row", "click", function() {
            var mpsqnty = $(this).parents("tr").find('input[name="mpsqnty[]"]').val()
            var grandtotal1 = $('#grandtotal1').val();
            var total1 = parseFloat(grandtotal1) - parseFloat(mpsqnty)

            $('#grandtotal1').val(total1);
            $(this).parents("tr").remove();
        });

    });
</script>
@stop