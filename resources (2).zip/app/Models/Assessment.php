<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Assessment extends Model
{
    use HasFactory;
    protected $table= 'assessment';
    protected $fillable = [
        'garde_id',
        'section_id',
        'student_id',
        'activity_id',
        'score',
    ];
}
