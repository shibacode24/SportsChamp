<?php

namespace App\Http\Controllers;

use App\Models\Activity;
use App\Models\Assessment;
use App\Models\Attendance;
use App\Models\DamageProp;
use App\Models\Leave;
use App\Models\masters\Blog;
use App\Models\masters\Ebook;
use App\Models\masters\Employee;
use App\Models\masters\Grade;
use App\Models\masters\IssueProp;
use App\Models\masters\ManageVideo;
use App\Models\masters\Prop;
use App\Models\masters\Section;
use App\Models\Notification;
use App\Models\Student;
use Illuminate\Http\Request;
use Nette\Utils\Json;
use Hash;

class ApiController extends Controller
{

    public function user_login(Request $request)
    {
        $user = Student::where('username', '=', $request->username)->first();
    
         if ($user && Hash::check($request->password, $user->password))
    {
        
            return response()->json(['status'=>true,'data' =>$user,'message'=>'Login Successfull']);
        }else{
            return response()->json(['status'=>false,'message'=>'data not found']);
        }
    }

    
   public function blog()
   {
    $blog = Blog :: get();

    if($blog->isNotEmpty())
    {
    return response()->json(['status'=>true ,'data'=>$blog]);
    }
    else{
    return response()->json(['status'=>false ,'message'=>'No Blog Found']);
      
    }
   }

   public function blog_data(Request $request)
   {
    $blog_data = Blog :: where('id',$request->blog_id)->get();

    if($blog_data->isNotEmpty())
    {
    return response()->json(['status'=>true ,'data'=>$blog_data]);
    }
    else{
    return response()->json(['status'=>false ,'message'=>'No Blog Found']);
      
    }
   }

   public function video()
   {
    $video = ManageVideo :: get();
    
    if($video->isNotEmpty())
    {
    return response()->json(['status'=>true ,'data'=>$video]);
    }
    else{
    return response()->json(['status'=>false ,'message'=>'No Video Found']);
      
    }
   }

   public function notification()
   {
    $notification = Notification :: where('select_user','Users')->get();
    
   if($notification->isNotEmpty())
    {
    return response()->json(['status'=>true ,'data'=>$notification]);
    }
    else{
    return response()->json(['status'=>false ,'message'=>'No Notification Found']);
      
    }
   }

   public function profile(Request $request)
   {
    $profile = Student :: where('id',$request->user_id)->first();
    
   if($profile)
    {
    return response()->json(['status'=>true ,'data'=>$profile]);
    }
    else{
    return response()->json(['status'=>false ,'message'=>'No profile Found']);
      
    }
   }
 
//--------------------------emp functions--------------------------------------------//

public function emp_login(Request $request)
{
    $emp = Employee::where('username', '=', $request->username)->first();

     if ($emp && Hash::check($request->password, $emp->password))
    {
        return response()->json(['status'=>true,'data' =>$emp,'message'=>'Login Successfull']);
    }else{
        return response()->json(['status'=>false,'message'=>'data not found']);
    }
}

public function get_grade()
{
 $grade = Grade :: get();
 
 if($grade->isNotEmpty())
 {
 return response()->json(['status'=>true ,'data'=>$grade]);
 }
 else{
 return response()->json(['status'=>false ,'message'=>'No grade Found']);
   
 }
}

public function get_section()
{
 $section = Section :: get();
 
 if($section->isNotEmpty())
 {
 return response()->json(['status'=>true ,'data'=>$section]);
 }
 else{
 return response()->json(['status'=>false ,'message'=>'No section Found']);
   
 }
}

public function get_e_book(Request $request)
{
 $e_book = Ebook :: where('grade_id',$request->grade_id)
 ->get();
 
 if($e_book->isNotEmpty())
 {
 return response()->json(['status'=>true ,'data'=>$e_book]);
 }
 else{
 return response()->json(['status'=>false ,'message'=>'No e_book Found']);
   
 }
}

public function get_student()
{
 $student = Student :: get();
 
 if($student->isNotEmpty())
 {
 return response()->json(['status'=>true ,'data'=>$student]);
 }
 else{
 return response()->json(['status'=>false ,'message'=>'No student Found']);
   
 }
}

public function get_issued_prop()
{
 $issued_prop = IssueProp :: get();
 
 if($issued_prop->isNotEmpty())
 {
 return response()->json(['status'=>true ,'data'=>$issued_prop]);
 }
 else{
 return response()->json(['status'=>false ,'message'=>'No issued_prop Found']);
   
 }
}

public function get_prop()
{
 $prop = Prop :: get();
 
 if($prop->isNotEmpty())
 {
 return response()->json(['status'=>true ,'data'=>$prop]);
 }
 else{
 return response()->json(['status'=>false ,'message'=>'No prop Found']);
   
 }
}

public function emp_notification()
{
 $emp_notification = Notification :: where('select_user','Employee')->get();
 
if($emp_notification->isNotEmpty())
 {
 return response()->json(['status'=>true ,'data'=>$emp_notification]);
 }
 else{
 return response()->json(['status'=>false ,'message'=>'No Notification Found']);
   
 }
}

public function emp_profile(Request $request)
{
 $emp_profile = Employee :: where('id',$request->emp_id)->first();
 
if($emp_profile)
 {
 return response()->json(['status'=>true ,'data'=>$emp_profile]);
 }
 else{
 return response()->json(['status'=>false ,'message'=>'No profile Found']);
   
 }
}

public function post_attendance(Request $request)
{
    $attendance = Attendance:: create([
        'emp_id' => $request->emp_id,
        'date' => $request->date,
        'start_time' => $request->start_time,
        'end_time' => $request->end_time,
    ]);

 return response()->json(['status'=>true ,'message'=>'Attendance Submitted Successfully']);

}

public function post_activity(Request $request)
{
    $activity = Activity:: create([
        'grade_id' => $request->grade_id,
        'section_id' => $request->section_id,
        'category' => $request->category,
        'activity' => $request->activity,
        'remark' => $request->remark,

    ]);

 return response()->json(['status'=>true ,'message'=>'Activity Submitted Successfully']);

}

public function post_assessment(Request $request)
{
    $assessment = Assessment:: create([
        'garde_id' => $request->garde_id,
        'section_id' => $request->section_id,
        'student_id' => $request->student_id,
        'activity_id' => $request->activity_id,
        'score' => $request->score,
    ]);

 return response()->json(['status'=>true ,'message'=>'Assessment Submitted Successfully']);

}

public function post_damage_prop(Request $request)
{
    $damageprop = DamageProp:: create([
        'prop_id' => $request->prop_id,
        'quantity' => $request->quantity,
        'date' => $request->date,
        'reason' => $request->reason,
    ]);

 return response()->json(['status'=>true ,'message'=>'Damageprop Submitted Successfully']);

}

public function post_leave(Request $request)
{
    $leave = Leave:: create([
        'leave_type' => $request->leave_type,
        'from_date' => $request->from_date,
        'to_date' => $request->to_date,
        'reason' => $request->reason,
    ]);

 return response()->json(['status'=>true ,'message'=>'Leave Submitted Successfully']);

}

}
