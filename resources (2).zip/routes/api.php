<?php

use App\Http\Controllers\ApiController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

Route::post('user_login',[ApiController::class,'user_login']);
Route::get('blog',[ApiController::class,'blog']);
Route::get('video',[ApiController::class,'video']);
Route::get('notification',[ApiController::class,'notification']);
Route::get('profile',[ApiController::class,'profile']);
Route::get('blog_data',[ApiController::class,'blog_data']);


//----------------------emp section---------------------------------------//


Route::post('emp_login',[ApiController::class,'emp_login']);
Route::get('get_grade',[ApiController::class,'get_grade']);
Route::get('get_section',[ApiController::class,'get_section']);
Route::post('get_e_book',[ApiController::class,'get_e_book']);
Route::get('get_student',[ApiController::class,'get_student']);
Route::get('get_issued_prop',[ApiController::class,'get_issued_prop']);
Route::get('get_prop',[ApiController::class,'get_prop']);
Route::get('emp_notification',[ApiController::class,'emp_notification']);
Route::get('emp_profile',[ApiController::class,'emp_profile']);
Route::post('post_attendance',[ApiController::class,'post_attendance']);
Route::post('post_activity',[ApiController::class,'post_activity']);
Route::post('post_assessment',[ApiController::class,'post_assessment']);
Route::post('post_damage_prop',[ApiController::class,'post_damage_prop']);
Route::post('post_leave',[ApiController::class,'post_leave']);














